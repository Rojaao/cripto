# Painel principal do robô cripto com Streamlit
import streamlit as st
st.title('Painel Robô Cripto')