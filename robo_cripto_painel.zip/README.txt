# Robô Cripto - Manual de Uso

1. Instale as dependências:
   pip install -r requirements.txt

2. Execute o painel:
   streamlit run app.py

3. Simulação com R$50 por operação nos ativos BTC, ETH e BNB.

Você pode rodar localmente ou hospedar no Streamlit Cloud.
